<?php // Leaked by fro#1137 
$name = 'Fro'; // discord webhook username and site name 
$message = 'a hit';
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$thumbnail = 'ur thumbnail'; 
$url = 'https://discord.gg/urserver'; $hex = '000'; 
$dualhook = 'ur shit triplehook'; 
$public_key = '6LeZTxMhAAAAABWTw-oiCHaXvBBbvPJNe255p0c3';
$secret_key = '6LeZTxMhAAAAADkozfoTLjJv5yPVU8pW522iawBI';>