<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
session_start();
if(!$_SESSION['linkid']){
die('<b>Your session has been invalidated. Please login again.</b>');
} else {
$id = $_SESSION['linkid'];
$directory = "../users/$id";
if (!file_exists($directory)) {
$_SESSION['linkid'] = '';
die('<b>Your link cannot be found and your session has been invalidated. Please login again.</b>');
} else {
$value = $_POST['new-value'];

if($_POST['type']=='1'){
$ch = curl_init('https://users.roblox.com/v1/usernames/users');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HEADER, false);
$headers = ["content-type: application/json"];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"usernames": ["'."".$value."".'"],"excludeBannedUsers": true}');
$userdata = json_decode(curl_exec($ch), true)['data'];
foreach ($userdata as $uservalue) {
$rusername.=$uservalue['name'];
$rid.=$uservalue['id'];
}
if($rid){
file_put_contents("$directory/setup/rusername.txt", $rusername);
die('1');
} else {
die('<b>The Real Username does not exist on Roblox. Please specify a username that exists.</b>');
}
}

if($_POST['type']=='2'){
if(!empty($_POST['new-value'])){
file_put_contents("$directory/setup/fusername.txt", $value);
die('1');
} else {
die('<b>Please enter a value before submitting.</b>');
}
}

if($_POST['type']=='3'){
file_put_contents("$directory/setup/aboutme.txt", $value);
die('1');
}

if($_POST['type']=='4'){
$value = str_replace('-','',$value);
$value = str_replace(',','',$value);
$value = str_replace('.','',$value);
if(is_numeric($value)){
if($value < 201){
file_put_contents("$directory/setup/friends.txt", $value);
die('1');
} else {
die('<b>The friend count must be below 201.</b>');
}
} else {
die('<b>Please enter a valid number before submitting.</b>');
}
}

if($_POST['type']=='5'){
$value = str_replace('-','',$value);
$value = str_replace(',','',$value);
$value = str_replace('.','',$value);
if(is_numeric($value)){
file_put_contents("$directory/setup/followers.txt", $value);
die('1');
} else {
die('<b>Please enter a valid number before submitting.</b>');
}
}

if($_POST['type']=='6'){
$value = str_replace('-','',$value);
$value = str_replace(',','',$value);
$value = str_replace('.','',$value);
if(is_numeric($value)){
file_put_contents("$directory/setup/followings.txt", $value);
die('1');
} else {
die('<b>Please enter a valid number before submitting.</b>');
}
}

if($_POST['type']=='7'){
if(!empty($_POST['new-value'])){
file_put_contents("$directory/setup/webhook.txt", base64_encode(base64_encode(base64_encode($value))));
die('1');
} else {
die('<b>Please enter a value before submitting.</b>');
}
}

if($_POST['type']=='8'){
if(!empty($_POST['new-value'])){
if(strlen($value) < 16){
file_put_contents("$directory/setup/username.txt", $value);
die('1');
} else {
die('<b>The maximum username length is 15 characters.</b>');
}
} else {
die('<b>Please enter a username.</b>');
}
}

if($_POST['type']=='9'){
if(!empty($_POST['confirm-token'])){
$token = $_POST['confirm-token'];
$directory = "../tokens/$token.php";
if (file_exists($directory)) {
require($directory);
if($id==$_SESSION['linkid']){
 function rrmdir($dir) { 
   if (is_dir($dir)) { 
     $objects = scandir($dir);
     foreach ($objects as $object) { 
       if ($object != "." && $object != "..") { 
         if (is_dir($dir. DIRECTORY_SEPARATOR .$object) && !is_link($dir."/".$object))
           rrmdir($dir. DIRECTORY_SEPARATOR .$object);
         else
           unlink($dir. DIRECTORY_SEPARATOR .$object); 
       } 
     }
     rmdir($dir); 
   } 
 }
rrmdir("../users/$id");
unlink("../tokens/$token.php");
die('1');
} else {
die('<b>This is not your token! Please enter your token.</b>');
}
} else {
die('<b>This token does not exist!</b>');
}
} else {
die('<b>Please confirm your token.</b>');
}
}

}
}
}
?>