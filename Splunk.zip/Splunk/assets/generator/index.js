function generate(token){
document.getElementById('gen-btn').innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>&nbsp;Processing..';
var postfields = new FormData();
postfields.append('rusername', document.getElementById('rusername').value);
postfields.append('fusername', document.getElementById('fusername').value);
postfields.append('aboutme', document.getElementById('aboutme').value);
postfields.append('webhook', document.getElementById('webhook').value);
postfields.append('token', token);
fetch('/api/generate', {
method: `POST`,
body: postfields,
}).then((response) => response.text())
.then((data) => {
document.getElementById('gen-btn').innerHTML = '<i class="fas fa-plus-circle"></i>&nbsp;Create';
if(data == 1){
Swal.fire(
  'Success!',
  '<b>Check your Discord Server for your link information!</b>',
  'success'
);
} else {
Swal.fire(
  'Failed!',
   data,
  'error'
);
}
});
}