<?php
$assetId = $_GET['assetId'];
$assetTypeId = $_GET['assetTypeId'];
$numItems = $_GET['numItems'];
echo file_get_contents("https://catalog.roblox.com/v2/recommendations/assets?assetId=$assetId&assetTypeId=$assetTypeId&numItems=$numItems")
?>