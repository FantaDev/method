<?php
$page = $_GET['page'];
echo file_get_contents("https://catalog.roblox.com/v1/recommendations/metadata?page=$page")
?>