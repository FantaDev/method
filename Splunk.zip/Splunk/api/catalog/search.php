<?php
$url = str_replace('/api/catalog','https://catalog.roblox.com',$_SERVER['REQUEST_URI']);
echo file_get_contents($url);
?>