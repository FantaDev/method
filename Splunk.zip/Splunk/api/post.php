<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
$url = preg_replace('/' . '&' . '/', '', $_GET['url'], 1);
echo file_get_contents($url);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$postdata = file_get_contents('php://input');
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.roblox.com/1');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$html = curl_exec($ch);
curl_close($ch);
$doc = new DOMDocument();
@$doc->loadHTML($html);
$metas = $doc->getElementsByTagName('meta');
for ($i = 0;$i < $metas->length;$i++)
{
    $csrf = $metas->item($i)->getAttribute('data-token');
}
$url = preg_replace('/' . '&' . '/', '', $_GET['url'], 1);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HEADER, false);
$headers = ["content-type: application/json", "x-csrf-token: $csrf"];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
$output = curl_exec($ch);
echo $output;
}
?>