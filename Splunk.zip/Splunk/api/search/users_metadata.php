<?php
$keyword = $_GET['keyword'];
echo file_get_contents("https://www.roblox.com/search/users/metadata?keyword=$keyword")
?>