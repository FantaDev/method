<?php
$keyword = $_GET['keyword'];
$maxRows = $_GET['maxRows'];
$startIndex = $_GET['startIndex'];
echo file_get_contents("https://www.roblox.com/search/users/results?keyword=$keyword&maxRows=$maxRows&startIndex=$startIndex")
?>