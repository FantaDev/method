<?php
$gameSortsContext = $_GET['gameSortsContext'];
echo file_get_contents("https://games.roblox.com/v1/games/sorts?gameSortsContext=$gameSortsContext")
?>