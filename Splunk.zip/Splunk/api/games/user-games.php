<?php
session_start();
if($_SESSION['userid']){
$userid = $_SESSION['userid'];
} else {
$userid = $_GET['userid'];
}
echo file_get_contents("https://games.roblox.com/v2/users/$userid/games?accessFilter=Public&limit=50");
?>