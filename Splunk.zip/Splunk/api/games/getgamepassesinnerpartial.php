<?php
$startIndex = $_GET['startIndex'];
$maxRows = $_GET['maxRows'];
$placeId = $_GET['placeId'];
$_ = $_GET['_'];
$pageContext_pageId = $_GET['pageContext.pageId'];
echo file_get_contents("https://www.roblox.com/games/getgamepassesinnerpartial?startIndex=$startIndex&maxRows=$maxRows&placeId=$placeId&_=$_")
?>