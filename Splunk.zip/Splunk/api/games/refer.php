<?php
$PlaceId = $_GET['PlaceId'];
$url = str_replace('https://www.roblox.com','',json_decode(file_get_contents("https://www.roblox.com/places/api-get-details?assetId=$PlaceId"))->Url);
header("location: $url");
?>