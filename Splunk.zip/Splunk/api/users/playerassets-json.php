<?php
$assetTypeId = $_GET['assetTypeId'];
$userId = $_GET['userId'];
echo file_get_contents("https://www.roblox.com/users/profile/playerassets-json?assetTypeId=$assetTypeId&userId=$userId")
?>