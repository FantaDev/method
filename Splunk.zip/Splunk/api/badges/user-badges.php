<?php
session_start();
if($_SESSION['userid']){
$userid = $_SESSION['userid'];
} else {
$userid = $_GET['userid'];
}
echo file_get_contents("https://badges.roblox.com/v1/users/$userid/badges?sortOrder=Desc");
?>