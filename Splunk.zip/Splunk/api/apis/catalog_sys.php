<?php
$parameters = $_GET['parameters'];
echo file_get_contents("https://apis.roblox.com/product-experimentation-platform/v1/projects/1/layers/AvatarMarketplace.RecommendationsAndSearch.Web/values?parameters=$parameters")
?>