<?php
session_start();
if($_SESSION['userid']){
$userid = $_SESSION['userid'];
} else {
$userid = $_GET['userid'];
}
echo file_get_contents("https://accountinformation.roblox.com/v1/users/$userid/roblox-badges");
?>