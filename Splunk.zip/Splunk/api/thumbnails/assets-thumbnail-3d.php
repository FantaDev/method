<?php
$assetId = $_GET['assetId'];
echo file_get_contents("https://thumbnails.roblox.com/v1/assets-thumbnail-3d?assetId=$assetId")
?>