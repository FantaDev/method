<?php
session_start();
if($_SESSION['userid']){
$userid = $_SESSION['userid'];
} else {
$userid = $_GET['userId'];
}
echo file_get_contents("https://thumbnails.roblox.com/v1/users/avatar-3d?userId=$userid");
?>