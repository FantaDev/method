<?php
$targetUserId = $_GET['targetUserId'];
echo file_get_contents("https://friends.roblox.com/v1/metadata?targetUserId=$targetUserId")
?>